export default function TestPage() {
  return (
    <div className="h-screen flex items-center justify-center bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500">
      <h1 className="text-5xl font-extrabold text-white drop-shadow-lg">
        🚀 Tailwind is Working!
      </h1>
    </div>
  );
}
